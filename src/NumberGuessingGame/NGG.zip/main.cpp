#include <iostream>
int main() {
  //This here assigns the random number "x".
  srand((unsigned)time(0)); 
    int x;
    x = (rand()%100)+1; 
  //This part displays the intro dialouge.
  std::cout << "Welcome to the number guessing game!\n";
  std::cout << "Guess a number between 1 and 100:\n";
  std::string test;
//This section displays the user input text and converts it into a readable integer.
using namespace std;
   char usin[100];
   cout << "Please enter your guess: ";
   cin >> usin;
   cout << "Your guess was: " << usin << endl;
       string s = usin;

    int resul = stoi(usin);
//This displays the results and checks for the quality of guess.
if(resul==x) {
  std::cout << "Congratulations, your guess was correct!";
} else if(resul>x) {
  std::cout << "Sorry, your guess was too high!\n";
  std::cout << "The correct number was actually: " << x << "!";
} else if(resul<x) {
  std::cout << "Sorry, your guess was too low!\n";
  std::cout << "The correct number was actually: " << x << "!";
}
}