#include <iostream>
using namespace std;
int main() {
  std::cout << "Welcome to the c++ madlib.\n";
  std::cout << "Let's get started with your words!\n";
  std::string adj1, adj2, ajd3, ajd4, adj5, adj6, noun1, noun2, pnoun1, pnoun2, pnoun3, adv1, verb1, lota1;
   cout << "Give me an ADJECTIVE... ";
   cin >> adj1;
   cout << "Give me another ADJECTIVE... "; 
   cin >> adj2;
   cout << "Give me a NOUN... ";
   cin >> noun1;
  cout << "Give me another NOUN... ";
   cin >> noun2;
   cout << "Give me a PLURAL NOUN... "; 
   cin >> pnoun1;
   cout << "Give me an ADVERB... ";
   cin >> adv1;
  cout << "Give me a VERB... ";
   cin >> verb1;
   cout << "Give me another ADJECTIVE... "; 
   cin >> ajd3;
   cout << "Give me another PLURAL NOUN... ";
   cin >> pnoun2;
  cout << "Give me another ADJECTIVE... ";
   cin >> ajd4;
   cout << "Give me another ADJECTIVE... "; 
   cin >> adj5;
  cout << "Give me another ADJECTIVE... "; 
   cin >> adj6;
   cout << "Give me another PLURAL NOUN... ";
   cin >> pnoun3;
  cout << "Give me a LETTER OF THE ALPHABET... "; 
   cin >> lota1;
   cout << "Here's the final result: \n";
cout << adj1 << "teachers always give out " << adj2 <<" assignments.\n"
"But, as everyone knows, if you want to pass all your classes so you can\n" 
"go to a(n) "<< noun1 <<" and become president of a big international\n" << 
noun1 << " and have millions of " << pnoun1 << " in the bank, you\n" <<
"must do your homework and study " << adv1 << ". If you just sit\n" <<
"around and" << verb1 << ", you won't get ahead in life. You must learn\n" << 
"to pay attention to every " << ajd3 << "thing your teacher says. do\n" <<
"not interrupt or whisper to other "<< pnoun2 << "during class. Be\n"
"sure to have a nice "<< ajd4 <<" notebook in which you can write\n"
<< "down anything the teacher says that seems "<< adj5 <<". Then go\n"
<< "home and memorize all of these "<<adj6<<" notes. And when your\n"
<< "teacher gives a suprise quiz, you will know all of the "<<pnoun3<<"\n"
"and will get a(n) "<< lota1 <<" as a grade for the class.";
}